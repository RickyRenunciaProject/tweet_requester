from setuptools import setup
setup(
  install_requires = [
    "ipython>=7.25.0",
    "google-cloud-translate>=3.3.1",
    "pandas",
  ],
)